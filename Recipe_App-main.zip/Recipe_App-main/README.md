# Recipe_App

Website : https://debrajhyper.github.io/Recipe_App/


    Find your everyday cooking inspiration on Recipe Website. 🥣

    * Discover recipes 🍙
    * cooks 🥧
    * videos 🎬
    * Cooking ideas ✨


# Website Info
Designed by <a href="https://github.com/debrajhyper">Debraj Karmakar</a>

Technology Used :
* HTML5
* CSS3
* Bootstrap
* jQuery
* JavaScript
* Fetch API {edamam.com}
* Github
* VS Code
* Chrome

<h3>Home</h3>
<img src="assets/Screenshot (52).png"/>
    
<h3>Search</h3>
<img src="assets/Screenshot (53).png"/>

<h3>Results</h3>
<img src="assets/Screenshot (54).png"/>
